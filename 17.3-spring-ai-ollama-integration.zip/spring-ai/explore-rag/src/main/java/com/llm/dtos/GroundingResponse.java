package com.llm.dtos;

public record GroundingResponse(String response) {
}
