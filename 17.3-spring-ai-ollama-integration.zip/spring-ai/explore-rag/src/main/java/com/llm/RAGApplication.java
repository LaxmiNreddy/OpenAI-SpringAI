package com.llm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RAGApplication {

	public static void main(String[] args) {
		SpringApplication.run(RAGApplication.class, args);
	}

}