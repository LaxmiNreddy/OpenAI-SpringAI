package com.llm.tool_calling.weather.dtos;

public record Condition(String text) {
}
