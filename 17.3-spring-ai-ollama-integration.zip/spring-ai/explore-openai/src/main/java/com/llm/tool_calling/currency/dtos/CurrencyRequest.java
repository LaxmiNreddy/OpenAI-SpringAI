package com.llm.tool_calling.currency.dtos;

public record CurrencyRequest(String base, String symbols) {}

