package com.llm.tool_calling.weather.dtos;

public record WeatherResponse(Location location, Current current) {
}

