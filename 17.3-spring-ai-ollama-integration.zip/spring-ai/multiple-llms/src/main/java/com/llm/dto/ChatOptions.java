package com.llm.dto;

public record ChatOptions(  Double temperature,
                             int maxTokens){

}
