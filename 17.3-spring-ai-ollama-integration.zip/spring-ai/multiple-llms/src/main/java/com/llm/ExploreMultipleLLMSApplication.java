package com.llm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExploreMultipleLLMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExploreMultipleLLMSApplication.class, args);
	}

}