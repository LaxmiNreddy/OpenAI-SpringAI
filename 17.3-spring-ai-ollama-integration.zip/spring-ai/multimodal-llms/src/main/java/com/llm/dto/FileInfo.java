package com.llm.dto;

public record FileInfo(String name,
                       String description) {
}
