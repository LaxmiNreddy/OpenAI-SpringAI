package com.llm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultimodalLLMApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultimodalLLMApplication.class, args);
    }

}