package com.llm.dto;

public record TranscriptionResponse(String transcription,
                                    String fileName) {
}
