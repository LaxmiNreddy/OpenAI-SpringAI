package com.llm.dto;

public record AIResponse(String content) {
}
